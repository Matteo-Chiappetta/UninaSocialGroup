package org.openjfx.Progetto.Entity.ClassiDao;

public class NotificaDao {

}
