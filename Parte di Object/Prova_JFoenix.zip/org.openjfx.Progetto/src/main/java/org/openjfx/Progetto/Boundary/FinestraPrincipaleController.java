package org.openjfx.Progetto.Boundary;

public class FinestraPrincipaleController {
	
}
