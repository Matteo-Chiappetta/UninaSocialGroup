package org.openjfx.Progetto.Entity;

import java.util.Date;

public class Interazione {
	private Date dataInterazione;

	public Date getDataInterazione() {
		return dataInterazione;
	}

	public void setDataInterazione(Date dataInterazione) {
		this.dataInterazione = dataInterazione;
	}
}
