package org.openjfx.Progetto.Entity;

import java.util.Date;

public class Notifica {
	private Date dataNotifica;

	public Date getDataNotifica() {
		return dataNotifica;
	}

	public void setDataNotifica(Date dataNotifica) {
		this.dataNotifica = dataNotifica;
	}
}
