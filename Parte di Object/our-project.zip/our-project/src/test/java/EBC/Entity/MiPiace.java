package EBC.Entity;

public class MiPiace extends Interazione {
	//Vedere come rappresentare in java la relazione post e mi piace 
}
