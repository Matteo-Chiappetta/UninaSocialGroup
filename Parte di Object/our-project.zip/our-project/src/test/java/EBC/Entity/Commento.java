package EBC.Entity;

public class Commento {
	private String commento;

	public String getCommento() {
		return commento;
	}

	public void setCommento(String commento) {
		this.commento = commento;
	}
}