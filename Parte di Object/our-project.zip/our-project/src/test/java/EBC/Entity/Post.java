package EBC.Entity;

import java.util.Date;

public class Post {
	private Date dataPubblicazione;
	private String didascalia;
	
	public Date getDataPubblicazione() {
		return dataPubblicazione;
	}
	public void setDataPubblicazione(Date dataPubblicazione) {
		this.dataPubblicazione = dataPubblicazione;
	}
	public String getDidascalia() {
		return didascalia;
	}
	public void setDidascalia(String didascalia) {
		this.didascalia = didascalia;
	}
	
}
